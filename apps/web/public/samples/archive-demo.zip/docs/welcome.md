# Welcome to the demo archive

This file lives **inside** `archive-demo.zip`. Open it from the archive listing and the viewer renders it in place — no new page.

- `docs/` — Markdown, PDF, DOCX and a plain-text note
- `data/` — CSV, JSON and an XLSX workbook
- `media/` — an MP4 clip, a PPTX deck, an SVG badge and a PNG image
- `nested/bundle.zip` — another archive: click it to browse inside the *same* breadcrumb

```ts
import { mountViewer } from "@gntrees/docs-viewer";

mountViewer("#app", { source: "/archive-demo.zip" });
```
